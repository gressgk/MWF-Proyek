<?php $__env->startSection('judul', 'Daftar Mitra - WeCare'); ?>

<?php $__env->startSection('konten'); ?>
    <section class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-7">
                <div class="wc-card p-4 p-md-5">
                    <div class="text-center mb-4">
                        <img src="<?php echo e(asset('img/mascot/duck-box.png')); ?>" style="height: 70px;" alt="Maskot WeCare">
                        <h4 class="fw-bold mt-3">Daftar Jadi Mitra WeCare</h4>
                        <p class="text-secondary small">
                            Dua langkah mudah sebelum akun diverifikasi Admin
                        </p>
                    </div>

                    <?php if(session('pesan')): ?>
                        <div class="alert alert-info small">
                            <?php echo e(session('pesan')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger small">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <ul class="nav nav-pills justify-content-center gap-2 mb-4">
                        <li class="nav-item">
                            <span class="nav-link <?php echo e($step == 1 ? 'active' : ''); ?>">
                                1. Data Akun
                            </span>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link <?php echo e($step == 2 ? 'active' : ''); ?>">
                                2. Data Organisasi
                            </span>
                        </li>
                    </ul>

                    
                    <?php if($step == 1): ?>
                        <form method="POST" action="<?php echo e(route('register.mitra.akun')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">
                                    Nama Penanggung Jawab
                                </label>
                                <input type="text" name="nama_pj" class="form-control"
                                    value="<?php echo e(old('nama_pj', $dataAkun['nama_pj'] ?? '')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email</label>
                                <input type="email" name="email" class="form-control"
                                    value="<?php echo e(old('email', $dataAkun['email'] ?? '')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">No. HP</label>
                                <input type="text" name="phone" class="form-control"
                                    value="<?php echo e(old('phone', $dataAkun['phone'] ?? '')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Password</label>
                                <input type="password" name="password" class="form-control" minlength="8" required>
                            </div>

                            <button type="submit" class="wc-btn-primary w-100">
                                Lanjut ke Data Organisasi
                            </button>
                        </form>

                        
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('register.mitra.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">
                                    Nama Organisasi / Yayasan
                                </label>
                                <input type="text" name="nama_organisasi" class="form-control"
                                    value="<?php echo e(old('nama_organisasi')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Jenis Organisasi</label>
                                <select name="jenis_organisasi" id="jenisOrganisasi" class="form-select" required>
                                    <option value="yayasan" <?php if(old('jenis_organisasi') == 'yayasan'): echo 'selected'; endif; ?>>
                                        Yayasan
                                    </option>
                                    <option value="individu" <?php if(old('jenis_organisasi') == 'individu'): echo 'selected'; endif; ?>>
                                        Individu
                                    </option>
                                    <option value="komunitas" <?php if(old('jenis_organisasi') == 'komunitas'): echo 'selected'; endif; ?>>
                                        Komunitas
                                    </option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Alamat</label>
                                <textarea name="alamat" class="form-control" rows="2" required><?php echo e(old('alamat')); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">
                                    Nomor Rekening Organisasi
                                </label>
                                <input type="text" name="nomor_rekening" class="form-control"
                                    value="<?php echo e(old('nomor_rekening')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">
                                    Upload KTP Penanggung Jawab
                                </label>
                                <input type="file" name="dokumen_ktp" class="form-control" accept=".pdf,.jpg,.jpeg,.png"
                                    required>
                            </div>

                            <div class="mb-4" id="wrapDokumenLegalitas">
                                <label class="form-label fw-semibold">
                                    Upload Dokumen Legalitas (Opsional)
                                </label>
                                <input type="file" name="dokumen_legalitas" id="inputDokumenLegalitas"
                                    class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                            </div>

                            <a href="<?php echo e(route('register.mitra')); ?>" class="wc-btn-outline d-block text-center mb-3">
                                Kembali ke Data Akun
                            </a>

                            <button type="submit" class="wc-btn-primary w-100">
                                Daftar & Kirim untuk Verifikasi
                            </button>
                        </form>
                    <?php endif; ?>

                    <p class="text-center small mt-4 mb-0">
                        Sudah punya akun?
                        <a href="<?php echo e(route('login')); ?>">Masuk di sini</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <?php if($step == 2): ?>
        <script>
            const jenisOrganisasi = document.getElementById('jenisOrganisasi');
            const wrapDokumenLegalitas = document.getElementById('wrapDokumenLegalitas');
            const inputDokumenLegalitas = document.getElementById('inputDokumenLegalitas');

            function toggleDokumenLegalitas() {
                if (jenisOrganisasi.value == 'individu') {
                    wrapDokumenLegalitas.style.display = 'none';
                    inputDokumenLegalitas.disabled = true;
                    inputDokumenLegalitas.value = '';
                } else {
                    wrapDokumenLegalitas.style.display = 'block';
                    inputDokumenLegalitas.disabled = false;
                }
            }

            jenisOrganisasi.addEventListener('change', toggleDokumenLegalitas);
            toggleDokumenLegalitas();
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/grace/Herd/fai/project/MWF-Proyek/resources/views/auth/register-mitra.blade.php ENDPATH**/ ?>