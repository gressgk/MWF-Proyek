<?php $__env->startSection('judul', 'Daftar Donatur - WeCare'); ?>

<?php $__env->startSection('konten'); ?>
    <section class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-6">
                <div class="wc-card p-4 p-md-5">
                    <div class="text-center mb-4">
                        <img src="<?php echo e(asset('img/mascot/duck-box.png')); ?>" style="height: 70px;" alt="Maskot WeCare">
                        <h4 class="fw-bold mt-3">Daftar Sebagai Donatur</h4>
                        <p class="text-secondary small">Mulai perjalanan berbagimu bersama WeCare</p>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger small">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Lengkap</label>
                            <input type="text" name="name" class="form-control" placeholder="Nama lengkap kamu"
                                value="<?php echo e(old('name')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="nama@email.com"
                                value="<?php echo e(old('email')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">No. HP</label>
                            <input type="text" name="phone" class="form-control" placeholder="08xxxxxxxxxx"
                                value="<?php echo e(old('phone')); ?>" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Minimal 8 karakter"
                                    required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Konfirmasi Password</label>
                                <input type="password" name="password_confirmation" class="form-control"
                                    placeholder="Ulangi password" required>
                            </div>
                        </div>
                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" name="setuju" id="setuju"
                                <?php echo e(old('setuju') ? 'checked' : ''); ?> required>
                            <label class="form-check-label small" for="setuju">
                                Saya menyetujui syarat & ketentuan serta kebijakan privasi WeCare
                            </label>
                        </div>
                        <button type="submit" class="wc-btn-primary w-100">Daftar Sekarang</button>
                    </form>

                    <p class="text-center small mt-4 mb-0">
                        Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk di sini</a>
                    </p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/grace/Herd/fai/project/MWF-Proyek/resources/views/auth/register-donatur.blade.php ENDPATH**/ ?>